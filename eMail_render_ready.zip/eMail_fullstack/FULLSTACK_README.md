# eMail — iOS + Web + Stripe + Entitlements (Scaffold)

## What you asked for
- iOS subscription: paid to you through Apple (StoreKit / App Store Connect)
- Web subscription: paid to you through Stripe
- Shared entitlements so the same user can be Pro on either platform

This repo includes:
- `eMail/ios/` SwiftUI app scaffold (same as before)
- `eMail/server/` Node/Express entitlements API + **Stripe Checkout + Webhook** (Monthly + Annual)
- `web/` Next.js scaffold web app with Monthly/Annual toggle + entitlement check

---

## Important Apple rule (so you don't get rejected)
On **iOS**, for digital services/features used in the iOS app, Apple generally requires In‑App Purchase.
So:
- ✅ iOS app: StoreKit subscription (Apple pays you as normal)
- ✅ Web app: Stripe subscription (Stripe pays you to your Stripe account)
- ⚠️ If you link to Stripe checkout from inside the iOS app, Apple may reject unless it’s for certain exempt cases.
The safe approach is: keep Stripe subscription flow on the web only, and keep iOS purchase inside the iOS app.

---

## Run backend
```bash
cd eMail/server
npm i
cp .env.example .env
npm run dev
```

### Configure Stripe
1) Create a Product + recurring Price ($5/mo) in Stripe
2) Put the Price ID into `STRIPE_PRICE_ID`
3) Create a webhook endpoint in Stripe pointing to:
   - `http://localhost:3000/stripe/webhook`
4) Copy the webhook signing secret into `STRIPE_WEBHOOK_SECRET`

---

## Run web app
```bash
cd web
npm i
cp .env.example .env
npm run dev
```

Open http://localhost:3001

---

## Make the web app “real”
Next steps:
- Add proper auth (magic link, Google, etc.) so email isn’t just a textbox
- Build mailbox UI (Inbox/Message/Compose) using the same app rules:
  - single-message flag only
  - per-account AI toggle
  - per-account signature + default subject
  - editable Smart Inbox categories/rules


## Annual plan (10% off)
- Monthly: $5/mo
- Annual: $54/yr (10% off)
Create both recurring prices in Stripe and both products in App Store Connect.
