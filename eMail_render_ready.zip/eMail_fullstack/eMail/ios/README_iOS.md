## Generating the Xcode project

This repo uses **XcodeGen** to generate `eMail.xcodeproj` deterministically.

1) Install XcodeGen:
```bash
brew install xcodegen
```

2) Generate project:
```bash
cd ios
xcodegen generate
open eMail.xcodeproj
```

If you prefer, you can also create a new SwiftUI App in Xcode named `eMail`
and then drag the `eMail/` folder into it (keeping folder references).

