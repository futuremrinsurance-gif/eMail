import Foundation
import StoreKit

@MainActor
final class SubscriptionService: ObservableObject {
    @Published var isSubscribed: Bool = false

    // NOTE: This is a scaffold. Implement StoreKit 2 purchase flow here.
    // - Fetch Product by AppConfig.proMonthlyProductId
    // - Purchase
    // - Listen for Transaction updates
    // - Verify entitlement

    func refreshSubscriptionState() async {
        // TODO: Implement real StoreKit 2 check
        isSubscribed = false
    }

    func purchase() async throws {
        // TODO: implement real purchase:
        // let product = ...
        // let result = try await product.purchase()
        // verify transaction, set isSubscribed
        isSubscribed = true // demo
    }

    func restore() async {
        // TODO: implement restore
    }
}
