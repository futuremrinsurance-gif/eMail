import Foundation

protocol MailProvider {
    var account: MailAccount { get }
    func listFolders() async throws -> [MailFolder]
    func listMessages(folderId: String) async throws -> [MailMessage]
    func getMessage(id: String) async throws -> MailMessage
    func setFlag(messageId: String, flagged: Bool) async throws
    func setRead(messageId: String, read: Bool) async throws
    func send(message: OutgoingMessage) async throws
}

struct OutgoingMessage: Hashable {
    var fromAccountId: UUID
    var to: [String]
    var cc: [String]
    var bcc: [String]
    var subject: String
    var body: String
}
