import Foundation

final class MicrosoftProviderStub: MailProvider {
    let account: MailAccount
    init(account: MailAccount) { self.account = account }

    func listFolders() async throws -> [MailFolder] { [] }
    func listMessages(folderId: String) async throws -> [MailMessage] { [] }
    func getMessage(id: String) async throws -> MailMessage { throw URLError(.badServerResponse) }
    func setFlag(messageId: String, flagged: Bool) async throws {}
    func setRead(messageId: String, read: Bool) async throws {}
    func send(message: OutgoingMessage) async throws {}
}
