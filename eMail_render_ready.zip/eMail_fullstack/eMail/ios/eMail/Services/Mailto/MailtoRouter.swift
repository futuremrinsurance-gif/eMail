import Foundation

struct MailtoDraft: Hashable {
    var to: [String]
    var cc: [String]
    var bcc: [String]
    var subject: String
    var body: String
}

final class MailtoRouter {
    func parse(url: URL) -> MailtoDraft? {
        guard url.scheme?.lowercased() == "mailto" else { return nil }

        let rawTo = url.resourceSpecifier.split(separator: "?").first.map(String.init) ?? ""
        let toList = rawTo
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        var cc: [String] = []
        var bcc: [String] = []
        var subject = ""
        var body = ""

        if let comps = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            for item in comps.queryItems ?? [] {
                switch item.name.lowercased() {
                case "cc": cc = (item.value ?? "").split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                case "bcc": bcc = (item.value ?? "").split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                case "subject": subject = item.value ?? ""
                case "body": body = item.value ?? ""
                default: break
                }
            }
        }

        return MailtoDraft(to: toList, cc: cc, bcc: bcc, subject: subject, body: body)
    }
}
