import Foundation

struct EntitlementResponse: Codable {
    let pro: Bool
    let source: String
}

final class EntitlementService {
    func fetchEntitlements(email: String) async throws -> EntitlementResponse {
        // Call backend /me/entitlements?email=...
        var comps = URLComponents(url: AppConfig.backendBaseURL.appendingPathComponent("/me/entitlements"), resolvingAgainstBaseURL: false)!
        comps.queryItems = [URLQueryItem(name: "email", value: email)]
        let url = comps.url!

        let (data, resp) = try await URLSession.shared.data(from: url)
        guard let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(EntitlementResponse.self, from: data)
    }
}
