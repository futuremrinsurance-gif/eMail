import Foundation

enum AppConfig {
    // StoreKit
    static let proMonthlyProductId = "com.email.pro.monthly"
    static let proAnnualProductId = "com.email.pro.annual"

    // Backend (optional): entitlements + allowlist
    // Replace with your domain, e.g. https://api.yourdomain.com
    static let backendBaseURL = URL(string: "http://localhost:3000")!

    // Feature flags
    static let enableDemoMailbox = true
}
