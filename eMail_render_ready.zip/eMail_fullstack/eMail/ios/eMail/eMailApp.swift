import SwiftUI

@main
struct eMailApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var theme = ThemeManager()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(theme)
                .tint(theme.accentColor)
        }
    }
}
