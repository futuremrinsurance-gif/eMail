import Foundation

final class Persistence {
    private let defaults = UserDefaults.standard

    func save<T: Codable>(_ value: T, key: String) {
        do {
            let data = try JSONEncoder().encode(value)
            defaults.set(data, forKey: key)
        } catch {
            print("Persistence save error:", error)
        }
    }

    func load<T: Codable>(_ type: T.Type, key: String) -> T? {
        guard let data = defaults.data(forKey: key) else { return nil }
        do {
            return try JSONDecoder().decode(type, from: data)
        } catch {
            print("Persistence load error:", error)
            return nil
        }
    }
}
