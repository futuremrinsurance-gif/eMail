import SwiftUI

@MainActor
final class ThemeManager: ObservableObject {
    @Published var theme: Theme = .system

    func apply(_ theme: Theme) {
        self.theme = theme
    }

    var accentColor: Color {
        switch theme {
        case .system: return .accentColor
        case .blue: return .blue
        case .midnight: return .indigo
        case .forest: return .green
        case .purple: return .purple
        case .crimson: return .red
        case .gold: return .yellow
        }
    }
}
