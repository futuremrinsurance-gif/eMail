import Foundation
import Combine

@MainActor
final class AppStore: ObservableObject {
    @Published var session: SessionState = .signedOut
    @Published var entitlement: EntitlementState = .unknown
    @Published var accounts: [MailAccount] = []
    @Published var accountPrefs: [UUID: AccountPreferences] = [:]
    @Published var preferences: AppPreferences = AppPreferences()
    @Published var smartGlobal: SmartInboxConfig = .default()

    // Demo mailbox
    @Published var demoFolders: [MailFolder] = []
    @Published var demoMessages: [MailMessage] = []

    private let persistence = Persistence()
    private let entitlementService = EntitlementService()
    private let mailtoRouter = MailtoRouter()

    init() {
        load()
        bootstrapDemoIfNeeded()
    }

    func load() {
        if let saved: PersistedState = persistence.load(PersistedState.self, key: "state") {
            self.accounts = saved.accounts
            self.accountPrefs = saved.accountPrefs
            self.preferences = saved.preferences
            self.smartGlobal = saved.smartGlobal
        } else {
            // defaults
            self.smartGlobal = .default()
        }
        if preferences.primarySendAccountId == nil, let first = accounts.first?.id {
            preferences.primarySendAccountId = first
        }
    }

    func save() {
        let state = PersistedState(accounts: accounts, accountPrefs: accountPrefs, preferences: preferences, smartGlobal: smartGlobal)
        persistence.save(state, key: "state")
    }

    func signIn(email: String) async {
        session = .signingIn
        // In real app: Continue with Apple / Google sign-in flows.
        // Here: simulate.
        try? await Task.sleep(nanoseconds: 400_000_000)
        session = .signedIn(UserProfile(email: email))
        await refreshEntitlements()
    }

    func signOut() {
        session = .signedOut
        entitlement = .unknown
    }

    func refreshEntitlements() async {
        guard case let .signedIn(profile) = session else { return }
        entitlement = .loading
        do {
            let res = try await entitlementService.fetchEntitlements(email: profile.email)
            entitlement = res.pro ? .pro(source: res.source) : .notPro
        } catch {
            // If backend unavailable, keep conservative: notPro
            entitlement = .notPro
        }
    }

    var hasAccessToMail: Bool {
        if case .pro = entitlement { return true }
        return false
    }

    func addDemoAccountIfEmpty() {
        guard accounts.isEmpty else { return }
        let a = MailAccount(provider: .imap, email: "demo@example.com", displayName: "Demo – Example", canSend: true)
        accounts.append(a)
        accountPrefs[a.id] = AccountPreferences()
        preferences.primarySendAccountId = a.id
        save()
    }

    func addAccount(_ account: MailAccount) {
        accounts.append(account)
        accountPrefs[account.id] = accountPrefs[account.id] ?? AccountPreferences()
        if preferences.primarySendAccountId == nil {
            preferences.primarySendAccountId = account.id
        }
        save()
    }

    func updateAccount(_ account: MailAccount) {
        guard let idx = accounts.firstIndex(where: {$0.id == account.id}) else { return }
        accounts[idx] = account
        save()
    }

    func deleteAccount(_ id: UUID) {
        accounts.removeAll { $0.id == id }
        accountPrefs[id] = nil
        if preferences.primarySendAccountId == id {
            preferences.primarySendAccountId = accounts.first?.id
        }
        save()
    }

    func prefs(for accountId: UUID) -> AccountPreferences {
        accountPrefs[accountId] ?? AccountPreferences()
    }

    func setPrefs(_ prefs: AccountPreferences, for accountId: UUID) {
        accountPrefs[accountId] = prefs
        save()
    }

    // MARK: Smart Inbox overrides
    func createOverrideFromGlobal(for accountId: UUID) {
        var p = prefs(for: accountId)
        p.useGlobalSmartRules = false
        p.smartOverride = smartGlobal // COPY (recommended)
        setPrefs(p, for: accountId)
    }

    // MARK: Demo mailbox
    private func bootstrapDemoIfNeeded() {
        guard AppConfig.enableDemoMailbox else { return }
        if demoFolders.isEmpty {
            demoFolders = [
                MailFolder(id: "inbox", name: "Inbox"),
                MailFolder(id: "sent", name: "Sent"),
                MailFolder(id: "trash", name: "Trash"),
            ]
        }
        if demoMessages.isEmpty {
            addDemoAccountIfEmpty()
            let acct = accounts.first!.id
            let now = Date()
            demoMessages = [
                MailMessage(
                    id: "m1",
                    accountId: acct,
                    folderId: "inbox",
                    subject: "Welcome to eMail",
                    from: MailAddress(name: "eMail", email: "hello@email.app"),
                    to: [MailAddress(name: "You", email: accounts.first!.email)],
                    cc: [],
                    bcc: [],
                    date: now.addingTimeInterval(-3600),
                    snippet: "This is a demo message so you can test the UI right away.",
                    body: "Thanks for trying eMail.\n\nThis is a demo mailbox item. Replace providers to sync real mail.",
                    isRead: false,
                    isFlagged: false
                ),
                MailMessage(
                    id: "m2",
                    accountId: acct,
                    folderId: "inbox",
                    subject: "Policy update",
                    from: MailAddress(name: "Farmers", email: "updates@farmersagency.com"),
                    to: [MailAddress(name: "You", email: accounts.first!.email)],
                    cc: [],
                    bcc: [],
                    date: now.addingTimeInterval(-9000),
                    snippet: "A quick update about your account settings and security…",
                    body: "This is another demo message.",
                    isRead: true,
                    isFlagged: true
                ),
            ]
        }
    }

    // MARK: Mailto routing
    func handleMailto(url: URL) -> MailtoDraft? {
        mailtoRouter.parse(url: url)
    }
}

struct PersistedState: Codable {
    var accounts: [MailAccount]
    var accountPrefs: [UUID: AccountPreferences]
    var preferences: AppPreferences
    var smartGlobal: SmartInboxConfig
}

enum SessionState: Equatable {
    case signedOut
    case signingIn
    case signedIn(UserProfile)
}

struct UserProfile: Equatable {
    let email: String
}

enum EntitlementState: Equatable {
    case unknown
    case loading
    case notPro
    case pro(source: String)
}
