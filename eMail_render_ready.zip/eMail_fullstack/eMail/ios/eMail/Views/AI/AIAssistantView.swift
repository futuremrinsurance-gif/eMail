import SwiftUI

struct AIAssistantView: View {
    let subject: String
    let body: String
    let onApply: (String, String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var prompt: String = ""
    @State private var tone: Tone = .professional
    @State private var generated: String = ""

    enum Tone: String, CaseIterable, Identifiable {
        case professional, friendly, shorter, direct
        var id: String { rawValue }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("What do you want?") {
                    TextField("e.g., Ask for an update on the claim", text: $prompt)
                    Picker("Tone", selection: $tone) {
                        ForEach(Tone.allCases) { t in
                            Text(t.rawValue.capitalized).tag(t)
                        }
                    }
                }

                Section("Draft") {
                    TextEditor(text: $generated)
                        .frame(minHeight: 240)
                }

                Section {
                    Button("Generate (Stub)") {
                        // TODO: call your AI provider
                        generated = sampleDraft()
                    }
                    Button("Apply to message") {
                        onApply(subject, generated.isEmpty ? body : generated)
                        dismiss()
                    }
                }
            }
            .navigationTitle("AI Writing")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    private func sampleDraft() -> String {
        let base = prompt.isEmpty ? "Draft a message." : prompt
        switch tone {
        case .professional:
            return "Hello,\n\n\(base)\n\nBest regards,"
        case .friendly:
            return "Hey there!\n\n\(base)\n\nThanks so much!"
        case .shorter:
            return "\(base)\n\nThanks!"
        case .direct:
            return "\(base)"
        }
    }
}
