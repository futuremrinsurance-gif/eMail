import SwiftUI

struct MailboxView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedFolder: MailFolder = MailFolder(id: "inbox", name: "Inbox")
    @State private var selectedAccountId: UUID? = nil

    var body: some View {
        NavigationStack {
            List {
                Section("Mailboxes") {
                    ForEach(store.demoFolders) { folder in
                        Button {
                            selectedFolder = folder
                        } label: {
                            HStack {
                                Text(folder.name)
                                Spacer()
                                if folder.id == selectedFolder.id {
                                    Image(systemName: "checkmark")
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                }

                Section("Accounts") {
                    ForEach(store.accounts) { acct in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(acct.displayName)
                                Text(acct.email).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if acct.id == (store.preferences.primarySendAccountId ?? acct.id) {
                                Text("Primary")
                                    .font(.caption2)
                                    .padding(.horizontal, 8).padding(.vertical, 4)
                                    .background(.thinMaterial)
                                    .cornerRadius(10)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedAccountId = acct.id
                        }
                    }
                }
            }
            .navigationTitle("Mailboxes")
            .toolbar {
                NavigationLink {
                    InboxView(folder: selectedFolder, accountIdFilter: selectedAccountId)
                } label: {
                    Text("Open")
                }
            }
        }
    }
}
