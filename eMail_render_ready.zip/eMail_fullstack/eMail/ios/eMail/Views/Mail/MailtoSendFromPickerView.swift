import SwiftUI

struct MailtoSendFromPickerView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    let draft: MailtoDraft
    @State private var presentingCompose = false
    @State private var selectedAccountId: UUID? = nil

    var body: some View {
        NavigationStack {
            List(sendableAccounts) { acct in
                Button {
                    selectedAccountId = acct.id
                    presentingCompose = true
                } label: {
                    HStack {
                        VStack(alignment: .leading) {
                            Text(acct.displayName)
                            Text(acct.email)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if acct.id == store.preferences.primarySendAccountId {
                            Text("Primary")
                                .font(.caption2)
                                .padding(.horizontal, 8).padding(.vertical, 4)
                                .background(.thinMaterial)
                                .cornerRadius(10)
                        }
                    }
                }
            }
            .navigationTitle("Send from")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                }
            }
            .sheet(isPresented: $presentingCompose, onDismiss: { dismiss() }) {
                if let id = selectedAccountId {
                    ComposeView(
                        mode: .new,
                        prefill: nil,
                        forcedFromAccountId: id
                    )
                    .onAppear {
                        // Prefill recipients AFTER selection (as requested)
                    }
                    .modifier(MailtoPrefillModifier(draft: draft))
                }
            }
        }
    }

    private var sendableAccounts: [MailAccount] {
        store.accounts.filter { $0.canSend }
    }
}

/// Prefills the ComposeView fields from mailto after selection.
/// Implemented as a view modifier so ComposeView stays reusable.
struct MailtoPrefillModifier: ViewModifier {
    let draft: MailtoDraft

    func body(content: Content) -> some View {
        content
            .environment(\.mailtoDraft, draft)
    }
}

private struct MailtoDraftKey: EnvironmentKey {
    static let defaultValue: MailtoDraft? = nil
}

extension EnvironmentValues {
    var mailtoDraft: MailtoDraft? {
        get { self[MailtoDraftKey.self] }
        set { self[MailtoDraftKey.self] = newValue }
    }
}
