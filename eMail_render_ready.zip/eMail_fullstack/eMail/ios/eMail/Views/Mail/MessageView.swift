import SwiftUI

struct MessageView: View {
    @EnvironmentObject private var store: AppStore
    let messageId: String

    @State private var showingComposeReply = false
    @State private var showingComposeForward = false

    var body: some View {
        if let msg = store.demoMessages.first(where: {$0.id == messageId}) {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text(msg.subject).font(.title2).bold()
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("From: \(msg.from.email)").font(.subheadline)
                            Text("To: \(msg.to.map{$0.email}.joined(separator: ", "))").font(.subheadline)
                        }
                        Spacer()
                    }
                    Divider()
                    Text(msg.body)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
            }
            .navigationTitle("Message")
            .toolbar {
                Menu {
                    Button(msg.isFlagged ? "Unflag" : "Flag") {
                        toggleFlagSingle(messageId: msg.id)
                    }
                    Button(msg.isRead ? "Mark as Unread" : "Mark as Read") {
                        toggleRead(messageId: msg.id)
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }

                ToolbarItemGroup(placement: .bottomBar) {
                    Button {
                        showingComposeReply = true
                    } label: { Label("Reply", systemImage: "arrowshape.turn.up.left") }

                    Spacer()

                    Button {
                        showingComposeForward = true
                    } label: { Label("Forward", systemImage: "arrowshape.turn.up.right") }
                }
            }
            .sheet(isPresented: $showingComposeReply) {
                ComposeView(mode: .reply(messageId: msg.id), prefill: msg, forcedFromAccountId: msg.accountId)
            }
            .sheet(isPresented: $showingComposeForward) {
                ComposeView(mode: .forward(messageId: msg.id), prefill: msg, forcedFromAccountId: msg.accountId)
            }
        } else {
            Text("Message not found").foregroundStyle(.secondary)
        }
    }

    private func toggleFlagSingle(messageId: String) {
        // SINGLE MESSAGE ONLY: No bulk endpoints exist.
        guard let idx = store.demoMessages.firstIndex(where: {$0.id == messageId}) else { return }
        store.demoMessages[idx].isFlagged.toggle()
    }

    private func toggleRead(messageId: String) {
        guard let idx = store.demoMessages.firstIndex(where: {$0.id == messageId}) else { return }
        store.demoMessages[idx].isRead.toggle()
    }
}
