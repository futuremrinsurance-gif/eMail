import SwiftUI

struct InboxView: View {
    @EnvironmentObject private var store: AppStore
    let folder: MailFolder
    let accountIdFilter: UUID?

    @State private var search = ""
    @State private var selection = Set<String>() // multi-select ids (no flag actions)
    @State private var showingCompose = false

    var body: some View {
        List(selection: $selection) {
            ForEach(filteredMessages) { msg in
                NavigationLink {
                    MessageView(messageId: msg.id)
                } label: {
                    MessageRow(message: msg)
                }
            }
        }
        .navigationTitle(folder.name)
        .searchable(text: $search)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showingCompose = true
                } label: {
                    Image(systemName: "square.and.pencil")
                }
            }
        }
        .sheet(isPresented: $showingCompose) {
            ComposeView(mode: .new, prefill: nil, forcedFromAccountId: store.preferences.primarySendAccountId)
        }
    }

    private var filteredMessages: [MailMessage] {
        let base = store.demoMessages
            .filter { $0.folderId == folder.id }
            .filter { accountIdFilter == nil ? true : $0.accountId == accountIdFilter! }

        let searched = search.isEmpty ? base : base.filter {
            $0.subject.localizedCaseInsensitiveContains(search) ||
            $0.from.email.localizedCaseInsensitiveContains(search) ||
            $0.snippet.localizedCaseInsensitiveContains(search)
        }

        return searched.sorted { $0.date > $1.date }
    }
}

struct MessageRow: View {
    let message: MailMessage

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(message.from.name ?? message.from.email)
                        .font(.headline)
                        .lineLimit(1)
                    Spacer()
                    Text(message.date, style: .time)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(message.subject)
                    .font(.subheadline)
                    .lineLimit(1)
                Text(message.snippet)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            if message.isFlagged {
                Image(systemName: "flag.fill")
                    .foregroundStyle(.orange)
            }
        }
        .padding(.vertical, 6)
    }
}
