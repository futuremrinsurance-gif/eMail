import SwiftUI

enum ComposeMode: Hashable {
    case new
    case reply(messageId: String)
    case forward(messageId: String)
}

struct ComposeView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.mailtoDraft) private var mailtoDraft

    let mode: ComposeMode
    let prefill: MailMessage?
    let forcedFromAccountId: UUID?

    @State private var fromAccountId: UUID? = nil

    @State private var to: String = ""
    @State private var cc: String = ""
    @State private var bcc: String = ""
    @State private var subject: String = ""
    @State private var body: String = ""

    @State private var showFromPicker = false
    @State private var showAI = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text("From")
                        Spacer()
                        Button {
                            showFromPicker = true
                        } label: {
                            Text(fromAccountDisplay)
                                .foregroundStyle(.secondary)
                        }
                    }
                    TextField("To", text: $to)
                    TextField("Cc", text: $cc)
                    TextField("Bcc", text: $bcc)
                    TextField("Subject", text: $subject)
                }

                Section {
                    TextEditor(text: $body)
                        .frame(minHeight: 240)
                }
            }
            .navigationTitle(title)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Send") {
                        // TODO: send via provider
                        dismiss()
                    }
                }
                ToolbarItem(placement: .bottomBar) {
                    if aiEnabledForCurrentAccount {
                        Button {
                            showAI = true
                        } label: {
                            Label("AI", systemImage: "sparkles")
                        }
                    }
                }
            }
            .onAppear {
                setupInitialFields()
            }
            .sheet(isPresented: $showFromPicker) {
                FromPickerView(
                    accounts: store.accounts.filter{$0.canSend},
                    selected: $fromAccountId
                )
                .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showAI) {
                AIAssistantView(
                    subject: subject,
                    body: body,
                    onApply: { newSubject, newBody in
                        if !newSubject.isEmpty { subject = newSubject }
                        body = newBody
                    }
                )
            }
        }
    }

    private var title: String {
        switch mode {
        case .new: return "New Message"
        case .reply: return "Reply"
        case .forward: return "Forward"
        }
    }

    private var fromAccountDisplay: String {
        guard let id = fromAccountId,
              let acct = store.accounts.first(where: {$0.id == id})
        else { return "Select" }
        return "\(acct.displayName) (\(acct.email))"
    }

    private var aiEnabledForCurrentAccount: Bool {
        guard let id = fromAccountId else { return false }
        return store.prefs(for: id).aiEnabled
    }

    private func setupInitialFields() {
        if fromAccountId == nil {
            // Default rules:
            // - New: primary
            // - Reply/Forward: received account (forcedFromAccountId)
            switch mode {
            case .new:
                fromAccountId = store.preferences.primarySendAccountId
            case .reply, .forward:
                fromAccountId = forcedFromAccountId ?? store.preferences.primarySendAccountId
            }
        }

        // Prefill recipients & subject for reply/forward
        if let msg = prefill {
            switch mode {
            case .reply:
                to = msg.from.email
                subject = msg.subject.hasPrefix("Re:") ? msg.subject : "Re: \(msg.subject)"
            case .forward:
                subject = msg.subject.hasPrefix("Fwd:") ? msg.subject : "Fwd: \(msg.subject)"
                body = "\n\n---- Forwarded message ----\n\(msg.body)"
            case .new:
                break
            }
        }

        // Prefill from mailto (external links) AFTER account selection
if case .new = mode, let d = mailtoDraft {
    if to.isEmpty { to = d.to.joined(separator: ", ") }
    if cc.isEmpty { cc = d.cc.joined(separator: ", ") }
    if bcc.isEmpty { bcc = d.bcc.joined(separator: ", ") }
    if subject.isEmpty { subject = d.subject }
    if body.isEmpty { body = d.body }
}

// Apply Default Subject (NEW only, and only if empty)
        if case .new = mode, subject.isEmpty, let id = fromAccountId {
            let p = store.prefs(for: id)
            if p.defaultSubjectEnabled, !p.defaultSubjectText.isEmpty {
                subject = p.defaultSubjectText
            }
        }

        // Apply Signature (per account)
        if let id = fromAccountId {
            let p = store.prefs(for: id)
            if p.signatureEnabled, !p.signatureText.isEmpty {
                // Append signature if not already present
                if !body.contains(p.signatureText) {
                    body += (body.isEmpty ? "" : "\n\n") + "--\n" + p.signatureText
                }
            }
        }
    }
}

struct FromPickerView: View {
    let accounts: [MailAccount]
    @Binding var selected: UUID?
    @Environment(\.dismiss) private var dismiss
    @Environment(\.mailtoDraft) private var mailtoDraft

    var body: some View {
        NavigationStack {
            List(accounts) { acct in
                Button {
                    selected = acct.id
                    dismiss()
                } label: {
                    VStack(alignment: .leading) {
                        Text(acct.displayName)
                        Text(acct.email).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Send From")
        }
    }
}
