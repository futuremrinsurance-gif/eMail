import SwiftUI

enum SmartScope: Hashable {
    case global
    case account(UUID)
}

struct SmartInboxEditorView: View {
    @EnvironmentObject private var store: AppStore
    let scope: SmartScope

    @State private var config: SmartInboxConfig = .default()
    @State private var showingAddCategory = false
    @State private var showingAddRule = false

    var body: some View {
        List {
            Section("Categories") {
                ForEach(config.categories.sorted(by: {$0.order < $1.order})) { cat in
                    HStack {
                        Text(cat.name)
                        Spacer()
                        Toggle("", isOn: Binding(
                            get: { cat.enabled },
                            set: { setCategoryEnabled(catId: cat.id, enabled: $0) }
                        ))
                        .labelsHidden()
                    }
                }
                .onMove(perform: moveCategories)
                .onDelete(perform: deleteCategories)

                Button {
                    showingAddCategory = true
                } label: { Label("Add Category", systemImage: "plus") }
            }

            Section("Rules") {
                if config.rules.isEmpty {
                    Text("No rules yet. Add rules to route mail into categories.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(config.rules) { rule in
                        VStack(alignment: .leading) {
                            Text(categoryName(rule.categoryId))
                                .font(.headline)
                            Text("\(rule.field.rawValue) \(rule.op.rawValue) "\(rule.value)"")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .onDelete(perform: deleteRules)
                }

                Button {
                    showingAddRule = true
                } label: { Label("Add Rule", systemImage: "plus") }
            }
        }
        .navigationTitle(title)
        .toolbar { EditButton() }
        .onAppear { loadConfig() }
        .onChange(of: config) { _, _ in persist() }
        .sheet(isPresented: $showingAddCategory) {
            AddCategorySheet { name in
                addCategory(name: name)
            }
        }
        .sheet(isPresented: $showingAddRule) {
            AddRuleSheet(categories: config.categories) { newRule in
                config.rules.append(newRule)
            }
        }
    }

    private var title: String {
        switch scope {
        case .global: return "Smart Inbox"
        case .account: return "Smart Inbox (Account)"
        }
    }

    private func loadConfig() {
        switch scope {
        case .global:
            config = store.smartGlobal
        case .account(let id):
            let prefs = store.prefs(for: id)
            config = prefs.smartOverride ?? store.smartGlobal
        }
    }

    private func persist() {
        switch scope {
        case .global:
            store.smartGlobal = config
            store.save()
        case .account(let id):
            var prefs = store.prefs(for: id)
            prefs.useGlobalSmartRules = false
            prefs.smartOverride = config
            store.setPrefs(prefs, for: id)
        }
    }

    private func categoryName(_ id: UUID) -> String {
        config.categories.first(where: {$0.id == id})?.name ?? "Unknown"
    }

    private func addCategory(name: String) {
        let nextOrder = (config.categories.map{$0.order}.max() ?? -1) + 1
        config.categories.append(SmartCategory(name: name, order: nextOrder, enabled: true))
    }

    private func setCategoryEnabled(catId: UUID, enabled: Bool) {
        guard let idx = config.categories.firstIndex(where: {$0.id == catId}) else { return }
        config.categories[idx].enabled = enabled
    }

    private func moveCategories(from source: IndexSet, to destination: Int) {
        var ordered = config.categories.sorted(by: {$0.order < $1.order})
        ordered.move(fromOffsets: source, toOffset: destination)
        for (i, c) in ordered.enumerated() {
            var c2 = c
            c2.order = i
            if let idx = config.categories.firstIndex(where: {$0.id == c.id}) {
                config.categories[idx] = c2
            }
        }
    }

    private func deleteCategories(at offsets: IndexSet) {
        let ordered = config.categories.sorted(by: {$0.order < $1.order})
        let idsToRemove = offsets.map { ordered[$0].id }
        config.categories.removeAll { idsToRemove.contains($0.id) }
        config.rules.removeAll { idsToRemove.contains($0.categoryId) }
    }

    private func deleteRules(at offsets: IndexSet) {
        config.rules.remove(atOffsets: offsets)
    }
}

struct AddCategorySheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name: String = ""
    let onAdd: (String) -> Void

    var body: some View {
        NavigationStack {
            Form {
                TextField("Category name", text: $name)
            }
            .navigationTitle("Add Category")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add") {
                        onAdd(name.trimmingCharacters(in: .whitespacesAndNewlines))
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

struct AddRuleSheet: View {
    @Environment(\.dismiss) private var dismiss
    let categories: [SmartCategory]
    let onAdd: (SmartRule) -> Void

    @State private var selectedCategory: UUID? = nil
    @State private var field: SmartField = .subject
    @State private var op: SmartOperator = .contains
    @State private var value: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Picker("Category", selection: $selectedCategory) {
                    ForEach(categories) { cat in
                        Text(cat.name).tag(Optional(cat.id))
                    }
                }
                Picker("Field", selection: $field) {
                    ForEach(SmartField.allCases) { f in
                        Text(f.rawValue).tag(f)
                    }
                }
                Picker("Operator", selection: $op) {
                    ForEach(SmartOperator.allCases) { o in
                        Text(o.rawValue).tag(o)
                    }
                }
                TextField("Value", text: $value)
            }
            .navigationTitle("Add Rule")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add") {
                        guard let cat = selectedCategory else { return }
                        onAdd(SmartRule(categoryId: cat, field: field, op: op, value: value))
                        dismiss()
                    }
                    .disabled(selectedCategory == nil || value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear { selectedCategory = categories.first?.id }
        }
    }
}
