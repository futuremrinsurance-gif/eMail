import SwiftUI

struct FetchNewDataView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        Form {
            Section("Fetch") {
                Picker("Schedule", selection: $store.preferences.fetchSchedule) {
                    Text("Automatically").tag(FetchSchedule.automatic)
                    Text("Every 15 Minutes").tag(FetchSchedule.minutes15)
                    Text("Every 30 Minutes").tag(FetchSchedule.minutes30)
                    Text("Every Hour").tag(FetchSchedule.hour1)
                    Text("Manually").tag(FetchSchedule.manual)
                }
            }

            Section("Per-account (stub)") {
                ForEach(store.accounts) { acct in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(acct.displayName)
                            Text(acct.email).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("Fetch")
                            .foregroundStyle(.secondary)
                    }
                }
                Text("Implement Push/Fetch/Manual per account based on provider support.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Fetch New Data")
        .onChange(of: store.preferences.fetchSchedule) { _, _ in store.save() }
    }
}
