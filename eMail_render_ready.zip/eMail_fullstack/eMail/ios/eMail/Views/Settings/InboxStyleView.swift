import SwiftUI

struct InboxStyleView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        Form {
            Picker("Default Inbox Style", selection: $store.preferences.defaultInboxMode) {
                Text("Smart Inbox").tag(InboxMode.smart)
                Text("Traditional Folders").tag(InboxMode.traditional)
            }
        }
        .navigationTitle("Inbox Style")
        .onChange(of: store.preferences.defaultInboxMode) { _, _ in store.save() }
    }
}
