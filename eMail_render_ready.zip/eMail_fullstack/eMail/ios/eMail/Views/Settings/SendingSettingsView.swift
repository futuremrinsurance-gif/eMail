import SwiftUI

struct SendingSettingsView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        Form {
            Section("Primary Send From") {
                Picker("Account", selection: Binding(
                    get: { store.preferences.primarySendAccountId ?? store.accounts.first?.id },
                    set: { store.preferences.primarySendAccountId = $0; store.save() }
                )) {
                    ForEach(store.accounts.filter{$0.canSend}) { acct in
                        Text("\(acct.displayName) (\(acct.email))").tag(Optional(acct.id))
                    }
                }
            }

            Section {
                Text("Rules:")
                Text("• New compose defaults to Primary").font(.footnote).foregroundStyle(.secondary)
                Text("• Reply/Forward defaults to receiving account").font(.footnote).foregroundStyle(.secondary)
                Text("• Changing From applies to a SINGLE message only").font(.footnote).foregroundStyle(.secondary)
                Text("• External mailto links show a one-tap From picker").font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Sending")
    }
}
