import SwiftUI

struct AccountDetailView: View {
    @EnvironmentObject private var store: AppStore
    let accountId: UUID

    @State private var account: MailAccount? = nil
    @State private var prefs: AccountPreferences = AccountPreferences()

    var body: some View {
        Form {
            if let account {
                Section("Account") {
                    TextField("Display Name", text: Binding(
                        get: { account.displayName },
                        set: { store.updateAccount(MailAccount(id: account.id, provider: account.provider, email: account.email, displayName: $0, canSend: account.canSend)) }
                    ))
                    Text(account.email).foregroundStyle(.secondary)
                }

                Section("AI Writing (per account)") {
                    Toggle("AI Writing Assistant", isOn: $prefs.aiEnabled)
                    Toggle("Send subject to AI", isOn: $prefs.aiSendSubject).disabled(!prefs.aiEnabled)
                    Toggle("Send recipient names to AI", isOn: $prefs.aiSendRecipients).disabled(!prefs.aiEnabled)
                    Toggle("Strip signature before AI", isOn: $prefs.aiStripSignature).disabled(!prefs.aiEnabled)
                }

                Section("Signature (per account)") {
                    Toggle("Use Signature", isOn: $prefs.signatureEnabled)
                    TextEditor(text: $prefs.signatureText)
                        .frame(minHeight: 100)
                        .disabled(!prefs.signatureEnabled)
                }

                Section("Default Subject (per account)") {
                    Toggle("Use Default Subject", isOn: $prefs.defaultSubjectEnabled)
                    TextField("Default Subject", text: $prefs.defaultSubjectText)
                        .disabled(!prefs.defaultSubjectEnabled)
                }

                Section("Smart Inbox") {
                    Toggle("Use global Smart Inbox rules", isOn: $prefs.useGlobalSmartRules)
                    if prefs.useGlobalSmartRules == false {
                        NavigationLink("Edit this account's categories") {
                            SmartInboxEditorView(scope: .account(accountId))
                        }
                        if prefs.smartOverride == nil {
                            Button("Create override from global (copy)") {
                                store.createOverrideFromGlobal(for: accountId)
                                prefs = store.prefs(for: accountId)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Account")
        .onAppear {
            self.account = store.accounts.first(where: {$0.id == accountId})
            self.prefs = store.prefs(for: accountId)
            if prefs.useGlobalSmartRules == false && prefs.smartOverride == nil {
                // recommended: copy global
                store.createOverrideFromGlobal(for: accountId)
                prefs = store.prefs(for: accountId)
            }
        }
        .onChange(of: prefs) { _, newValue in
            store.setPrefs(newValue, for: accountId)
        }
    }
}
