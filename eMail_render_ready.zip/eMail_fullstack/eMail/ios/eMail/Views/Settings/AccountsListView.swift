import SwiftUI

struct AccountsListView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingAdd = false

    var body: some View {
        List {
            Section {
                ForEach(store.accounts) { acct in
                    NavigationLink {
                        AccountDetailView(accountId: acct.id)
                    } label: {
                        VStack(alignment: .leading) {
                            Text(acct.displayName)
                            Text(acct.email).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { idx in
                    for i in idx {
                        store.deleteAccount(store.accounts[i].id)
                    }
                }
            }

            Section {
                Button {
                    showingAdd = true
                } label: {
                    Label("Add Account", systemImage: "plus")
                }
            }
        }
        .navigationTitle("Accounts")
        .sheet(isPresented: $showingAdd) {
            AddAccountView()
        }
    }
}
