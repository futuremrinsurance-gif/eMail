import SwiftUI

struct ThemeSettingsView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var theme: ThemeManager

    var body: some View {
        Form {
            Picker("Theme", selection: Binding(
                get: { store.preferences.theme },
                set: { store.preferences.theme = $0; theme.apply($0); store.save() }
            )) {
                ForEach(Theme.allCases) { t in
                    Text(t.displayName).tag(t)
                }
            }
        }
        .navigationTitle("Themes")
        .onAppear { theme.apply(store.preferences.theme) }
    }
}
