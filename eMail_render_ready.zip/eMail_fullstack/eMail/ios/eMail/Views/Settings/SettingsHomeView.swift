import SwiftUI

struct SettingsHomeView: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink("Accounts") { AccountsListView() }
                NavigationLink("Fetch New Data") { FetchNewDataView() }
                NavigationLink("Sending") { SendingSettingsView() }
                NavigationLink("Inbox Style") { InboxStyleView() }
                NavigationLink("Smart Inbox Categories") { SmartInboxEditorView(scope: .global) }
                NavigationLink("Themes") { ThemeSettingsView() }
            }
            .navigationTitle("Settings")
        }
    }
}
