import SwiftUI

struct AddAccountView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    @State private var provider: AccountProvider = .imap
    @State private var email: String = ""
    @State private var displayName: String = ""

    var body: some View {
        NavigationStack {
            Form {
                Picker("Provider", selection: $provider) {
                    Text("Gmail (OAuth)").tag(AccountProvider.gmail)
                    Text("Microsoft (OAuth)").tag(AccountProvider.microsoft)
                    Text("Other Mail (IMAP/SMTP)").tag(AccountProvider.imap)
                }

                TextField("Email", text: $email)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("Display Name (e.g., Robert – Farmers)", text: $displayName)

                if provider == .imap {
                    Section("IMAP/SMTP (stub)") {
                        Text("Add IMAP/SMTP fields + validation here.")
                            .foregroundStyle(.secondary)
                    }
                } else {
                    Section("OAuth (stub)") {
                        Text("Implement OAuth flows for Gmail/Graph here.")
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Add Account")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add") {
                        let acct = MailAccount(
                            provider: provider,
                            email: email.lowercased(),
                            displayName: displayName.isEmpty ? email : displayName,
                            canSend: true
                        )
                        store.addAccount(acct)
                        dismiss()
                    }
                    .disabled(email.isEmpty)
                }
            }
        }
    }
}
