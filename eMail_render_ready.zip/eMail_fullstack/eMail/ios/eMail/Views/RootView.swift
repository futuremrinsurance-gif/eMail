import SwiftUI

struct RootView: View {
    @EnvironmentObject private var store: AppStore

    @State private var mailtoDraft: MailtoDraft? = nil
    @State private var showMailtoPicker: Bool = false

    var body: some View {
        Group {
            switch store.session {
            case .signedOut, .signingIn:
                AuthView()
            case .signedIn:
                if store.entitlement == .unknown || store.entitlement == .loading {
                    LoadingView(title: "Checking access…")
                        .task { await store.refreshEntitlements() }
                } else if store.hasAccessToMail == false {
                    PaywallView()
                } else {
                    MainTabView()
                }
            }
        }
        .onOpenURL { url in
            // External link clicks only: mailto handler
            if let draft = store.handleMailto(url: url) {
                mailtoDraft = draft
                showMailtoPicker = true
            }
        }
        .sheet(isPresented: $showMailtoPicker) {
            if let draft = mailtoDraft {
                MailtoSendFromPickerView(draft: draft)
            }
        }
    }
}
