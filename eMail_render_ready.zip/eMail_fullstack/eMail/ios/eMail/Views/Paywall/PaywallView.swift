import SwiftUI

struct PaywallView: View {
    @EnvironmentObject private var store: AppStore
    @StateObject private var subs = SubscriptionService()

    var body: some View {
        NavigationStack {
            VStack(spacing: 14) {
                Spacer()
                Text("Go Pro")
                    .font(.largeTitle).bold()
                Text("$4.99 / month • 3-day free trial").foregroundStyle(.secondary)
                Text("Or $54 / year • Save 10%").foregroundStyle(.secondary)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 10) {
                    Label("Unlimited email accounts", systemImage: "infinity")
                    Label("Themes + Smart Inbox", systemImage: "paintpalette")
                    Label("AI writing (per account)", systemImage: "sparkles")
                    Label("Safer flagging (no bulk flag)", systemImage: "flag")
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.thinMaterial)
                .cornerRadius(14)
                .padding(.horizontal)

                VStack(spacing: 10) {
    Button {
        Task {
            // TODO: purchase monthly (AppConfig.proMonthlyProductId)
            try? await subs.purchase()
            store.entitlement = .pro(source: "iap-monthly-demo")
        }
    } label: {
        Text("Start free trial (Monthly)")
            .frame(maxWidth: .infinity)
    }
    .buttonStyle(.borderedProminent)

    Button {
        Task {
            // TODO: purchase annual (AppConfig.proAnnualProductId)
            try? await subs.purchase()
            store.entitlement = .pro(source: "iap-annual-demo")
        }
    } label: {
        Text("Start free trial (Annual • Save 10%)")
            .frame(maxWidth: .infinity)
    }
    .buttonStyle(.bordered)
}
.padding(.horizontal)


                Button("Restore Purchases") {
                    Task { await subs.restore() }
                }
                .font(.footnote)

                Spacer()

                Button("Sign out") { store.signOut() }
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .padding(.bottom, 6)
            }
            .padding()
            .navigationTitle("Subscription")
        }
    }
}
