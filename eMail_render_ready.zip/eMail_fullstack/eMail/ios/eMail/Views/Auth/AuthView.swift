import SwiftUI

struct AuthView: View {
    @EnvironmentObject private var store: AppStore
    @State private var email = "futuremrguitar@gmail.com" // demo default

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Spacer()
                Text("eMail")
                    .font(.largeTitle).bold()
                Text("Sign in to continue")
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Demo sign-in email")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    TextField("Email", text: $email)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                }
                .padding(.horizontal)

                Button {
                    Task { await store.signIn(email: email.lowercased()) }
                } label: {
                    Text("Continue (Demo)")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding(.horizontal)

                Spacer()
                Text("Replace this demo with Continue with Apple + Google OAuth.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding()
        }
    }
}
