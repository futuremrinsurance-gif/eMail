import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            MailboxView()
                .tabItem { Label("Mail", systemImage: "tray") }
            SettingsHomeView()
                .tabItem { Label("Settings", systemImage: "gear") }
        }
    }
}
