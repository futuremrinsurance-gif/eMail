import Foundation

enum AccountProvider: String, Codable, CaseIterable {
    case gmail
    case microsoft
    case imap
}

struct MailAccount: Identifiable, Codable, Hashable {
    let id: UUID
    var provider: AccountProvider
    var email: String
    var displayName: String
    var canSend: Bool

    init(id: UUID = UUID(), provider: AccountProvider, email: String, displayName: String, canSend: Bool = true) {
        self.id = id
        self.provider = provider
        self.email = email
        self.displayName = displayName
        self.canSend = canSend
    }
}
