import Foundation

struct AccountPreferences: Codable, Hashable {
    // AI
    var aiEnabled: Bool = false
    var aiSendSubject: Bool = false
    var aiSendRecipients: Bool = false
    var aiStripSignature: Bool = true

    // Compose
    var signatureEnabled: Bool = true
    var signatureText: String = "Sent with eMail"
    var defaultSubjectEnabled: Bool = false
    var defaultSubjectText: String = ""

    // Inbox mode override
    var useGlobalSmartRules: Bool = true
    var inboxModeOverride: InboxMode? = nil
    var smartOverride: SmartInboxConfig? = nil // when useGlobalSmartRules == false

    init() {}
}
