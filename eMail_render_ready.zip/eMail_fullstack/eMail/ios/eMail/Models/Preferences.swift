import Foundation

enum InboxMode: String, Codable, CaseIterable, Identifiable {
    case smart
    case traditional
    var id: String { rawValue }
}

enum FetchSchedule: String, Codable, CaseIterable, Identifiable {
    case automatic
    case minutes15
    case minutes30
    case hour1
    case manual
    var id: String { rawValue }
}

struct AppPreferences: Codable {
    var primarySendAccountId: UUID? = nil
    var defaultInboxMode: InboxMode = .traditional
    var fetchSchedule: FetchSchedule = .automatic
    var theme: Theme = .system
}
