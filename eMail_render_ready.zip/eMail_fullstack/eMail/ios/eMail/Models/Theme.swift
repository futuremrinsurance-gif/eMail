import Foundation

enum Theme: String, Codable, CaseIterable, Identifiable {
    case system
    case blue
    case midnight
    case forest
    case purple
    case crimson
    case gold

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .system: return "System"
        case .blue: return "Blue"
        case .midnight: return "Midnight"
        case .forest: return "Forest"
        case .purple: return "Purple"
        case .crimson: return "Crimson"
        case .gold: return "Gold"
        }
    }
}
