import Foundation

enum SmartField: String, Codable, CaseIterable, Identifiable {
    case fromEmail, fromName, toEmail, subject, body, domain, hasAttachment
    var id: String { rawValue }
}

enum SmartOperator: String, Codable, CaseIterable, Identifiable {
    case contains, equals, startsWith
    var id: String { rawValue }
}

struct SmartCategory: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var order: Int
    var enabled: Bool

    init(id: UUID = UUID(), name: String, order: Int, enabled: Bool = true) {
        self.id = id
        self.name = name
        self.order = order
        self.enabled = enabled
    }
}

struct SmartRule: Identifiable, Codable, Hashable {
    let id: UUID
    var categoryId: UUID
    var field: SmartField
    var op: SmartOperator
    var value: String

    init(id: UUID = UUID(), categoryId: UUID, field: SmartField, op: SmartOperator, value: String) {
        self.id = id
        self.categoryId = categoryId
        self.field = field
        self.op = op
        self.value = value
    }
}

struct SmartInboxConfig: Codable, Hashable {
    var categories: [SmartCategory]
    var rules: [SmartRule]
    var defaultCategoryId: UUID?

    static func `default`() -> SmartInboxConfig {
        let primary = SmartCategory(name: "Primary", order: 0)
        let finance = SmartCategory(name: "Finance", order: 1)
        let travel = SmartCategory(name: "Travel", order: 2)
        let subscriptions = SmartCategory(name: "Subscriptions", order: 3)
        let updates = SmartCategory(name: "Updates", order: 4)

        return SmartInboxConfig(
            categories: [primary, finance, travel, subscriptions, updates],
            rules: [],
            defaultCategoryId: primary.id
        )
    }
}
