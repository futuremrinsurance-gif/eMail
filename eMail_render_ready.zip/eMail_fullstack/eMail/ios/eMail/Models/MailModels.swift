import Foundation

struct MailFolder: Identifiable, Codable, Hashable {
    let id: String
    var name: String
}

struct MailAddress: Codable, Hashable {
    var name: String?
    var email: String
}

struct MailMessage: Identifiable, Codable, Hashable {
    let id: String
    var accountId: UUID
    var folderId: String
    var subject: String
    var from: MailAddress
    var to: [MailAddress]
    var cc: [MailAddress]
    var bcc: [MailAddress]
    var date: Date
    var snippet: String
    var body: String
    var isRead: Bool
    var isFlagged: Bool
}
