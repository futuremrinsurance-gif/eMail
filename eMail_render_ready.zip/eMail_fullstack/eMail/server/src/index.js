import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import Stripe from "stripe";
import { fileURLToPath } from "url";
import { getStripeRecord, upsertStripeRecord } from "./stripeStore.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Stripe needs raw body for webhook verification, so we add JSON parsing conditionally.
app.use((req, res, next) => {
  if (req.originalUrl === "/stripe/webhook") {
    next();
  } else {
    express.json()(req, res, next);
  }
});

app.use(cors());

const PORT = process.env.PORT || 3000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "change_me";

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || "";
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";
const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID || "";
const STRIPE_PRICE_ID_ANNUAL = process.env.STRIPE_PRICE_ID_ANNUAL || "";
const APP_BASE_URL = process.env.APP_BASE_URL || "http://localhost:3001";

const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;

const allowlistPath = path.join(__dirname, "..", "data", "allowlist.json");
const stripeDbPath = path.join(__dirname, "..", "data", "stripe_customers.json");

function readAllowlist() {
  const raw = fs.readFileSync(allowlistPath, "utf-8");
  const json = JSON.parse(raw);
  return (json.allowlist || []).map((e) => String(e).toLowerCase());
}
function writeAllowlist(list) {
  fs.writeFileSync(allowlistPath, JSON.stringify({ allowlist: list }, null, 2));
}

function requireAdmin(req, res, next) {
  const token = req.header("x-admin-token");
  if (token !== ADMIN_TOKEN) return res.status(401).json({ error: "unauthorized" });
  next();
}

// Health
app.get("/", (_req, res) => res.json({ ok: true, service: "email-entitlements-server" }));

/**
 * Entitlements:
 * pro if:
 *  - email is allowlisted OR
 *  - stripe subscription active (web) OR
 *  - apple subscription active (iOS)  [stub; implement App Store Server API / notifications]
 */
app.get("/me/entitlements", (req, res) => {
  const email = String(req.query.email || "").toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "email required" });

  const allowlist = readAllowlist();
  const isAllowlisted = allowlist.includes(email);

  const stripeRec = getStripeRecord(stripeDbPath, email);
  const hasStripe = Boolean(stripeRec?.active);

  // Apple is stubbed in this scaffold.
  const hasApple = false;

  const pro = isAllowlisted || hasStripe || hasApple;
  const source = isAllowlisted ? "allowlist" : hasStripe ? "stripe" : hasApple ? "apple" : "none";
  return res.json({ pro, source });
});

// Admin allowlist
app.post("/admin/allowlist/add", requireAdmin, (req, res) => {
  const email = String(req.body.email || "").toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "email required" });
  const allowlist = readAllowlist();
  if (!allowlist.includes(email)) allowlist.push(email);
  writeAllowlist(allowlist);
  res.json({ ok: true, allowlist });
});
app.post("/admin/allowlist/remove", requireAdmin, (req, res) => {
  const email = String(req.body.email || "").toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "email required" });
  let allowlist = readAllowlist();
  allowlist = allowlist.filter((e) => e !== email);
  writeAllowlist(allowlist);
  res.json({ ok: true, allowlist });
});

/**
 * Stripe: create checkout session
 * Body: { email }
 */
app.post("/stripe/create-checkout-session", async (req, res) => {
  if (!stripe) return res.status(500).json({ error: "Stripe not configured" });
  const email = String(req.body.email || "").toLowerCase().trim();
  const plan = String(req.body.plan || "monthly").toLowerCase();
  if (!email) return res.status(400).json({ error: "email required" });

  const priceId =
    plan === "annual" ? STRIPE_PRICE_ID_ANNUAL : STRIPE_PRICE_ID;

  if (!priceId) {
    return res.status(500).json({ error: "Stripe price id not set for selected plan" });
  }

  try {
    // Reuse customer if known
    const existing = getStripeRecord(stripeDbPath, email);
    let customerId = existing?.customerId;

    if (!customerId) {
      const customer = await stripe.customers.create({ email });
      customerId = customer.id;
      upsertStripeRecord(stripeDbPath, email, { customerId, active: false });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: priceId, quantity: 1 }],
      allow_promotion_codes: true,
      success_url: `${APP_BASE_URL}/billing/success`,
      cancel_url: `${APP_BASE_URL}/billing/cancel`,
      subscription_data: {
        // Keep parity with iOS: 3-day trial (optional for web)
        trial_period_days: 3
      },
      metadata: {
        email,
        plan
      }
    });

    res.json({ url: session.url });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to create checkout session" });
  }
});

/**
 * Stripe customer portal (optional)
 * Body: { email }
 */
app.post("/stripe/create-portal-session", async (req, res) => {
  if (!stripe) return res.status(500).json({ error: "Stripe not configured" });
  const email = String(req.body.email || "").toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "email required" });

  const rec = getStripeRecord(stripeDbPath, email);
  if (!rec?.customerId) return res.status(404).json({ error: "No customer" });

  try {
    const portal = await stripe.billingPortal.sessions.create({
      customer: rec.customerId,
      return_url: `${APP_BASE_URL}/settings`
    });
    res.json({ url: portal.url });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Failed to create portal session" });
  }
});

/**
 * Stripe Webhook: updates `active` status based on subscription events
 */
app.post("/stripe/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  if (!stripe) return res.status(500).send("Stripe not configured");
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Webhook signature verification failed.", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const sub = event.data.object;
        const customerId = sub.customer;
        const status = sub.status; // active, trialing, canceled, etc.
        const isActive = status === "active" || status === "trialing";

        // Find by customerId
        const db = JSON.parse(fs.readFileSync(stripeDbPath, "utf-8"));
        const entries = Object.entries(db.customers || {});
        const match = entries.find(([, v]) => v.customerId === customerId);
        if (match) {
          const [email] = match;
          upsertStripeRecord(stripeDbPath, email, { active: isActive });
        }
        break;
      }
      default:
        break;
    }
  } catch (e) {
    console.error("Webhook handling error:", e);
    return res.status(500).send("Webhook handler failed");
  }

  res.json({ received: true });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
