import fs from "fs";
import path from "path";

export function readJson(filePath) {
  const raw = fs.readFileSync(filePath, "utf-8");
  return JSON.parse(raw);
}
export function writeJson(filePath, obj) {
  fs.writeFileSync(filePath, JSON.stringify(obj, null, 2));
}

export function getStripeRecord(dbPath, email) {
  const db = readJson(dbPath);
  return db.customers[email] || null;
}

export function upsertStripeRecord(dbPath, email, record) {
  const db = readJson(dbPath);
  db.customers[email] = { ...(db.customers[email] || {}), ...record };
  writeJson(dbPath, db);
  return db.customers[email];
}
