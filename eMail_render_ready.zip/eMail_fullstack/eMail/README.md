# eMail (iOS) — SwiftUI Codebase (Scaffold)

This is a **production-grade scaffold** for the eMail app you specified:
- Apple Mail-like UI structure (Inbox, Message, Compose, Settings)
- **Sign-in required → Paywall required → then add email accounts**
- StoreKit 2 subscription (3-day trial) **stubbed** + entitlement gating
- Allowlist-based free Pro via backend entitlement (sample Node server included)
- Unlimited accounts
- Flagging is **single-message only** (no bulk flag actions in UI)
- Per-account:
  - AI writing toggle (UI stub)
  - Signature (kept per account)
  - Default Subject (new mail only)
- Default Mail app behavior:
  - Handles `mailto:` links
  - **External links only** show a one-tap “Send From” picker (account name + email)
  - Tap account → immediately opens Compose (recipients shown after)
- Smart Inbox with **editable categories** and **global by default**, with optional per-account override
  - Overrides start as a **copy** of global categories (recommended)

> IMPORTANT
This repo is a **complete, runnable iOS app scaffold** with clean architecture + screens + state management.
The actual provider integrations (Gmail API, Microsoft Graph, IMAP/SMTP sync) are represented as interfaces + stubs,
because they require credentials, app registrations, and considerable protocol work.

## Requirements
- Xcode 15+ (Swift 5.9+)
- iOS 16+

## How to run
1. Open `ios/eMail.xcodeproj` in Xcode
2. Select a simulator (iPhone 15) and Run

## Where to implement real email connectivity
- `ios/eMail/Services/Mail/` contains protocols + stubs:
  - `MailProvider.swift`
  - `GmailProviderStub.swift`
  - `MicrosoftProviderStub.swift`
  - `IMAPProviderStub.swift`
Replace stubs with real implementations.

## Backend (optional but recommended)
A minimal Node/Express backend is included at `server/` for:
- allowlist entitlements (free Pro accounts)
- returning `pro: true/false` to the app
- simple admin endpoints

### Run server
```bash
cd server
npm i
cp .env.example .env
npm run dev
```

### Configure allowlist
Edit `server/data/allowlist.json` OR use admin endpoints:
- `POST /admin/allowlist/add` with header `x-admin-token`

## App Store Subscription
You must create an auto-renewable subscription in App Store Connect:
- Product ID: `com.email.pro.monthly`
- Intro offer: 3-day trial

Then update:
- `ios/eMail/Config/AppConfig.swift` (bundle + product ids)
- StoreKit sandbox testing accounts

## Notes
- The app ships with an **in-memory demo mailbox** so the UI flows are testable immediately.
- All “dangerous” bulk flagging paths are removed by design.

