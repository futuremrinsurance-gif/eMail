export const metadata = { title: "eMail Web", description: "eMail web app" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial", margin: 0 }}>
        <div style={{ padding: 16, borderBottom: "1px solid #e5e5e5" }}>
          <b>eMail Web</b>
          <span style={{ marginLeft: 10, color: "#666" }}>Subscription via Stripe</span>
        </div>
        <div style={{ padding: 16 }}>{children}</div>
      </body>
    </html>
  );
}
