"use client";

import { useMemo, useState } from "react";

const API = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3000";

export default function Home() {
  const [email, setEmail] = useState("futuremrguitar@gmail.com");
  const [entitlement, setEntitlement] = useState<{pro:boolean, source:string} | null>(null);
  const [plan, setPlan] = useState<"monthly" | "annual">("monthly");
  const canUseApp = entitlement?.pro;

  const api = useMemo(() => API, []);

  async function check() {
    const res = await fetch(`${api}/me/entitlements?email=${encodeURIComponent(email.toLowerCase())}`);
    const json = await res.json();
    setEntitlement(json);
  }

  async function subscribe(plan: "monthly" | "annual") {
  const res = await fetch(`${api}/stripe/create-checkout-session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, plan })
  });
  const json = await res.json();
  if (json.url) window.location.href = json.url;
  else alert(JSON.stringify(json));
}/stripe/create-checkout-session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email })
    });
    const json = await res.json();
    if (json.url) window.location.href = json.url;
    else alert(JSON.stringify(json));
  }

  return (
    <div style={{ maxWidth: 720 }}>
      <h1>eMail Web</h1>
      <p>This is a scaffold web app that shares the same entitlement backend.</p>

      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="your@email.com"
          style={{ padding: 10, flex: 1 }}
        />
        <button onClick={check} style={{ padding: "10px 14px" }}>Check Access</button>
      </div>

      {entitlement && (
        <div style={{ marginTop: 12, padding: 12, border: "1px solid #e5e5e5", borderRadius: 10 }}>
          <div><b>Pro:</b> {String(entitlement.pro)}</div>
          <div><b>Source:</b> {entitlement.source}</div>
        </div>
      )}

      <div style={{ marginTop: 16, padding: 12, border: "1px solid #e5e5e5", borderRadius: 10 }}>
  <h3>Subscription</h3>
  <p>
    On the web, you can charge via Stripe (paid to your Stripe account).
    On iOS, Apple In-App Purchase is required for in-app subscription (paid to you through Apple as normal).
  </p>

  <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
    <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
      <input
        type="radio"
        checked={plan === "monthly"}
        onChange={() => setPlan("monthly")}
      />
      Monthly ($5/mo)
    </label>

    <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
      <input
        type="radio"
        checked={plan === "annual"}
        onChange={() => setPlan("annual")}
      />
      Annual ($54/yr • Save 10%)
    </label>
  </div>

  <div style={{ marginTop: 12 }}>
    <button
      onClick={() => subscribe(plan)}
      style={{ padding: "10px 14px" }}
    >
      {plan === "monthly" ? "Subscribe ($5/mo)" : "Subscribe ($54/yr)"}
    </button>
  </div>
</div>
<div style={{ marginTop: 16, padding: 12, border: "1px solid #e5e5e5", borderRadius: 10 }}>
        <h3>App UI</h3>
        {canUseApp ? (
          <p>✅ Access granted. Next step: implement mail providers + UI on web (Inbox/Compose) using the same rules.</p>
        ) : (
          <p>🔒 No access yet. Subscribe or add email to allowlist.</p>
        )}
      </div>
    </div>
  );
}
