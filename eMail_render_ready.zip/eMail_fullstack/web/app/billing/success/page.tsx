export default function Success() {
  return (
    <div style={{ maxWidth: 720 }}>
      <h1>Success</h1>
      <p>Your subscription checkout completed. Entitlements will update after Stripe webhook processes the subscription.</p>
      <a href="/">Go back</a>
    </div>
  );
}
