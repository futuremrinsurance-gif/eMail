export default function Cancel() {
  return (
    <div style={{ maxWidth: 720 }}>
      <h1>Cancelled</h1>
      <p>No worries — you can subscribe anytime.</p>
      <a href="/">Go back</a>
    </div>
  );
}
